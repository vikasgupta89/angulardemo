import { Component } from '@angular/core';

@Component({
  selector: 'app-tender-style',
  imports: [],
  templateUrl: './tender-style.component.html',
  styleUrl: './tender-style.component.css'
})
export class TenderStyleComponent {

}
