import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TenderStyleComponent } from './tender-style.component';

describe('TenderStyleComponent', () => {
  let component: TenderStyleComponent;
  let fixture: ComponentFixture<TenderStyleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TenderStyleComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TenderStyleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
