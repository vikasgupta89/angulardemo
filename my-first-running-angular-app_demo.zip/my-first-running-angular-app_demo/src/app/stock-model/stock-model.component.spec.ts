import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StockModelComponent } from './stock-model.component';

describe('StockModelComponent', () => {
  let component: StockModelComponent;
  let fixture: ComponentFixture<StockModelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [StockModelComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StockModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
