import { Component } from '@angular/core';

@Component({
  selector: 'app-stock-model',
  imports: [],
  templateUrl: './stock-model.component.html',
  styleUrl: './stock-model.component.css'
})
export class StockModelComponent {

}
