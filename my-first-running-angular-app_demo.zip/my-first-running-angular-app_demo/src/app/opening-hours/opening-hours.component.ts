import { Component } from '@angular/core';

@Component({
  selector: 'app-opening-hours',
  imports: [],
  templateUrl: './opening-hours.component.html',
  styleUrl: './opening-hours.component.css'
})
export class OpeningHoursComponent {

}
