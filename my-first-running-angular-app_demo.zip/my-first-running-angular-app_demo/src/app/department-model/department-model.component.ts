import { Component } from '@angular/core';

@Component({
  selector: 'app-department-model',
  imports: [],
  templateUrl: './department-model.component.html',
  styleUrl: './department-model.component.css'
})
export class DepartmentModelComponent {

}
