import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DepartmentModelComponent } from './department-model.component';

describe('DepartmentModelComponent', () => {
  let component: DepartmentModelComponent;
  let fixture: ComponentFixture<DepartmentModelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DepartmentModelComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DepartmentModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
