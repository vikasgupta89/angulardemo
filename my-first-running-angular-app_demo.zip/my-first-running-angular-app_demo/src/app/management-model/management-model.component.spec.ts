import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagementModelComponent } from './management-model.component';

describe('ManagementModelComponent', () => {
  let component: ManagementModelComponent;
  let fixture: ComponentFixture<ManagementModelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ManagementModelComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ManagementModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
