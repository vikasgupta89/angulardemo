import { Component } from '@angular/core';

@Component({
  selector: 'app-management-model',
  imports: [],
  templateUrl: './management-model.component.html',
  styleUrl: './management-model.component.css'
})
export class ManagementModelComponent {

}
