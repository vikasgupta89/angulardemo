import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JemmaStudioComponent } from './jemma-studio.component';

describe('JemmaStudioComponent', () => {
  let component: JemmaStudioComponent;
  let fixture: ComponentFixture<JemmaStudioComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [JemmaStudioComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(JemmaStudioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
