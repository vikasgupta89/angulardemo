import { Component } from '@angular/core';

@Component({
  selector: 'app-jemma-studio',
  imports: [],
  templateUrl: './jemma-studio.component.html',
  styleUrl: './jemma-studio.component.css'
})
export class JemmaStudioComponent {

}
