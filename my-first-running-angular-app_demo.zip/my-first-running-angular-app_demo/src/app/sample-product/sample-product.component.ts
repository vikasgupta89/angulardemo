import { Component } from '@angular/core';

@Component({
  selector: 'app-sample-product',
  imports: [],
  templateUrl: './sample-product.component.html',
  styleUrl: './sample-product.component.css'
})
export class SampleProductComponent {

}
