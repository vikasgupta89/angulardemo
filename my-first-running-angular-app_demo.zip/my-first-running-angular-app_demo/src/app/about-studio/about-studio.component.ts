import { Component } from '@angular/core';

@Component({
  selector: 'app-about-studio',
  imports: [],
  templateUrl: './about-studio.component.html',
  styleUrl: './about-studio.component.css'
})
export class AboutStudioComponent {

}
