import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { NavbarComponent } from './navbar/navbar.component';
import { FooterComponent } from './footer/footer.component';
import { CardComponent } from './card/card.component';
import { ManagementModelComponent } from './management-model/management-model.component';
import { DepartmentModelComponent } from './department-model/department-model.component';
import { StockModelComponent } from './stock-model/stock-model.component';
import { AboutStudioComponent } from './about-studio/about-studio.component';
import { TenderStyleComponent } from './tender-style/tender-style.component';
import { JemmaStudioComponent } from './jemma-studio/jemma-studio.component';
import { SampleProductComponent } from './sample-product/sample-product.component';
import { CreativeIdeasComponent } from './creative-ideas/creative-ideas.component';
import { OpeningHoursComponent } from './opening-hours/opening-hours.component';

@Component({
  selector: 'app-root',
  //imports: [AboutStudioComponent,FooterComponent],
  imports: [NavbarComponent,TenderStyleComponent,JemmaStudioComponent,SampleProductComponent,CreativeIdeasComponent,OpeningHoursComponent,FooterComponent],
  //imports: [NavbarComponent,CardComponent,FooterComponent,ManagementModelComponent,DepartmentModelComponent,StockModelComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'my-first-running-angular-app';
}
