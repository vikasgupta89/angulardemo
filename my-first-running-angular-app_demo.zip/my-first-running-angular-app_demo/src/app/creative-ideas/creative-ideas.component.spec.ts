import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreativeIdeasComponent } from './creative-ideas.component';

describe('CreativeIdeasComponent', () => {
  let component: CreativeIdeasComponent;
  let fixture: ComponentFixture<CreativeIdeasComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CreativeIdeasComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CreativeIdeasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
