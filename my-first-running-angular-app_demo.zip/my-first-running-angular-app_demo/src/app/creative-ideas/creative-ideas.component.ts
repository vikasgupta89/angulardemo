import { Component } from '@angular/core';

@Component({
  selector: 'app-creative-ideas',
  imports: [],
  templateUrl: './creative-ideas.component.html',
  styleUrl: './creative-ideas.component.css'
})
export class CreativeIdeasComponent {

}
